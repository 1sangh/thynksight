package com.example.diapplication

import android.view.View
import android.widget.TextView
import androidx.test.core.app.ActivityScenario
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.BoundedMatcher
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.diapplication.ui.activity.MainActivity
import org.hamcrest.Description
import org.hamcrest.Matcher
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class MainActivityTest {


    @Before
    fun setup() {
        ActivityScenario.launch(MainActivity::class.java)
    }

    @Test
    fun testTextViewVisibility() {
        onView(withId(R.id.tvTastebuds)).check(matches(isDisplayed()))
    }


    @Test
    fun test_tvTastebuds_textIsCorrect() {
        onView(withId(R.id.tvTastebuds)).check(matches(withText(R.string.tastebuds)))
    }

    @Test
    fun test_tvTastebuds_textSize() {
        onView(withId(R.id.tvTastebuds)).check(matches(hasTextSize(40f)))
    }

    @Test
    fun test_tvTastebuds_textColorIsBlack() {
        onView(withId(R.id.tvTastebuds)).check(matches(hasTextColor(R.color.black)))
    }

    @Test
    fun test_tvHeading_isDisplayed() {
        onView(withId(R.id.tvHeading)).check(matches(isDisplayed()))
    }

    @Test
    fun test_tvHeading_textIsCorrect() {
        onView(withId(R.id.tvHeading)).check(matches(withText(R.string.popular_recipes)))
    }

    @Test
    fun test_tvHeading_textSize() {
        onView(withId(R.id.tvHeading)).check(matches(hasTextSize(20f)))
    }

    @Test
    fun test_tvHeading_textColorIsBlack() {
        onView(withId(R.id.tvHeading)).check(matches(hasTextColor(R.color.black)))
    }

    @Test
    fun test_recyclerView_isDisplayed() {
        onView(withId(R.id.recyclerView)).check(matches(isDisplayed()))
    }

    @Test
    fun test_recyclerView_hasItems() {
        onView(withId(R.id.recyclerView)).check(matches(hasMinimumChildCount(1)))
    }

    fun hasTextSize(expectedSp: Float): Matcher<View> {
        return object : BoundedMatcher<View, TextView>(TextView::class.java) {
            override fun describeTo(description: Description) {
                description.appendText("with text size: $expectedSp sp")
            }

            override fun matchesSafely(textView: TextView): Boolean {
                val actualSp = textView.textSize / textView.resources.displayMetrics.scaledDensity
                return actualSp == expectedSp
            }
        }
    }
}
