package com.example.diapplication

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import com.example.diapplication.model.MealsResponse
import com.example.diapplication.repository.MealRepository
import com.example.diapplication.ui.viewmodel.MealsViewModel
import junit.framework.Assert.assertEquals
import junit.framework.Assert.assertNull
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.*
import org.junit.*
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito.*
import org.mockito.MockitoAnnotations
import org.mockito.junit.MockitoJUnitRunner
import retrofit2.Response

@ExperimentalCoroutinesApi
@RunWith(MockitoJUnitRunner::class)
class MealsViewModelTest {

    @get:Rule
    val instantExecutorRule = InstantTaskExecutorRule() // Executes LiveData changes instantly

    @Mock
    private lateinit var repository: MealRepository

    private lateinit var viewModel: MealsViewModel

    private val testDispatcher = StandardTestDispatcher()

    @Before
    fun setup() {
        MockitoAnnotations.openMocks(this)
        Dispatchers.setMain(testDispatcher)
        viewModel = MealsViewModel(repository)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `fetchMeals() should update LiveData with success response`() = runTest {
        val mealsResponse = MealsResponse(listOf())
        val response = Response.success(mealsResponse)

        `when`(repository.getRandomMeals()).thenReturn(response)
        viewModel.fetchMeals()
        advanceUntilIdle()
        assertEquals(mealsResponse, viewModel.meals.value)
    }

    @Test
    fun `fetchMeals() should update LiveData with null on failure`() = runTest {
        val response = Response.error<MealsResponse>(400, mock())

        `when`(repository.getRandomMeals()).thenReturn(response)

        viewModel.fetchMeals()
        advanceUntilIdle()
        assertNull(viewModel.meals.value)
    }
}
