package com.example.diapplication.ui.viewmodel

import com.example.diapplication.model.MealsResponse
import com.example.diapplication.repository.MealRepository

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MealsViewModel @Inject constructor(private val repository: MealRepository) : ViewModel() {

    private val _meals = MutableLiveData<MealsResponse?>()
    val meals: LiveData<MealsResponse?> = _meals

    fun fetchMeals() {
        viewModelScope.launch {
            val response = repository.getRandomMeals()
            if (response.isSuccessful) {
                _meals.postValue(response.body())
            } else {
                _meals.postValue(null)
            }
        }
    }
}
