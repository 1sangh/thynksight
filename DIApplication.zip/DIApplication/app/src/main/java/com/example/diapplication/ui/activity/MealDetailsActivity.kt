package com.example.diapplication.ui.activity

import android.content.Intent
import android.os.Bundle
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.example.diapplication.databinding.ActivityMealDetailsBinding
import com.example.diapplication.model.Ingredient
import com.example.diapplication.ui.adapter.IngredientAdapter
import com.google.android.material.bottomsheet.BottomSheetBehavior
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MealDetailsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMealDetailsBinding
    private lateinit var ingredientsAdapter: IngredientAdapter
    private lateinit var bottomSheetBehavior: BottomSheetBehavior<FrameLayout>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMealDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        mealDetailsData()
        registerListener()

    }

    private fun mealDetailsData() {
        val mealName = intent.getStringExtra("MEAL_NAME") ?: "Unknown Meal"
        val mealInstructions =
            intent.getStringExtra("MEAL_INSTRUCTIONS") ?: "No instructions available"
        val mealImage = intent.getStringExtra("MEAL_IMAGE") ?: ""

        val ingredients = listOf(
            Ingredient("Potatoes", "https://www.themealdb.com/images/ingredients/Potatoes.png"),
            Ingredient("Chicken", "https://www.themealdb.com/images/ingredients/Chicken.png"),
            Ingredient("Tomato", "https://www.themealdb.com/images/ingredients/Tomato.png"),
            Ingredient("Potatoes", "https://www.themealdb.com/images/ingredients/Potatoes.png"),
            Ingredient("Chicken", "https://www.themealdb.com/images/ingredients/Chicken.png"),
            Ingredient("Tomato", "https://www.themealdb.com/images/ingredients/Tomato.png")
        )

        binding.tvMealName.text = mealName
        binding.tvArea.text = mealInstructions
        Glide.with(this).load(mealImage).into(binding.ivMealImage)

        ingredientsAdapter = IngredientAdapter(ingredients)
        binding.rvIngredients.layoutManager = LinearLayoutManager(this)
        binding.rvIngredients.adapter = ingredientsAdapter

        val bottomSheet = binding.bottomSheet
        bottomSheetBehavior = BottomSheetBehavior.from(bottomSheet)

        bottomSheetBehavior.apply {
            isHideable = false
            state = BottomSheetBehavior.STATE_COLLAPSED
        }
    }

    private fun registerListener() {
        binding.ivCross.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(intent)
        }

    }
}
