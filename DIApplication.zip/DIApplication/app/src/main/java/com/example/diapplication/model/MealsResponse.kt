package com.example.diapplication.model

data class MealsResponse(
    val meals: List<Meal>
)