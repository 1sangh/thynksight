package com.example.diapplication.repository

import com.example.diapplication.model.MealsResponse
import com.example.diapplication.network.ApiService
import retrofit2.Response
import javax.inject.Inject

class MealRepository @Inject constructor(private val apiService: ApiService) {
    suspend fun getRandomMeals(): Response<MealsResponse> {
        return apiService.getRandomMeals()
    }
}
