package com.example.diapplication.network

import com.example.diapplication.model.MealsResponse
import retrofit2.Response
import retrofit2.http.GET

interface ApiService {
    @GET("api/json/v2/1/randomselection.php")
    suspend fun getRandomMeals(): Response<MealsResponse>
}
