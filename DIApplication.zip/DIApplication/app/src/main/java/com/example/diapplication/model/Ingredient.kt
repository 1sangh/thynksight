package com.example.diapplication.model

data class Ingredient(  val name: String,
                        val imageUrl: String)
