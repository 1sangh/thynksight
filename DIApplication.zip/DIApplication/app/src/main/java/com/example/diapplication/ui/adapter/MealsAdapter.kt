package com.example.diapplication.ui.adapter


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.diapplication.databinding.ItemMealBinding
import com.example.diapplication.model.Meal

class MealsAdapter(private val mealsList: List<Meal>,private val onItemClick: (Meal) -> Unit):
    RecyclerView.Adapter<MealsAdapter.MealViewHolder>() {

    inner class MealViewHolder(private val binding: ItemMealBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(meal: Meal) {
            binding.tvSubHeading.text = meal.strMeal
            binding.tvDetails.text = meal.strInstructions
            binding.tvIngredients.text = meal.strArea

            Glide.with(binding.root)
                .load(meal.strMealThumb)
                .into(binding.ivMeal)

            binding.tvSubHeading.setOnClickListener {
                onItemClick(meal)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MealViewHolder {
        val binding = ItemMealBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MealViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MealViewHolder, position: Int) {
        holder.bind(mealsList[position])

    }

    override fun getItemCount(): Int = mealsList.size
}
